=============================================================
30/11/2018
=============================================================
Title		 : Order of the Dew
Filename	 : TDP20AC_OrderOfTheDew.zip
Author		 : Jayrude
Contact		 : Can PM me under the username HavvicGames on TTLG
Date of release	 : 30/11/2018

"It's that time of month again, it won't be long before the landlord comes knocking for his rent. I contacted one of my informants hoping to find an easy job. What he gave me was... interesting. He told me about a secret society of mages rumoured to be operating somewhere in the city and that they had recently received a magical sceptre from a rich benefactor. He couldn't give me anything more than that so I had to do my own investigation.

My research lead me to rumours about a nearby tavern, one of my old favourite drinking spots in fact. It seems it recently changed ownership and the new owner spent a lot of time remodelling. When I talked to some regulars I found out that there are a lot of rich people who come in and simply go into the kitchen, not to be seen again for many hours. Seems like the rumours are correct. I haven't yet had an opportunity to scout the area out due to the recently introduced curfew. If it's anything like how it used to be this should be an easy job.

Hopefully the society itself will have a good amount of money in, but if not I know there's a hammer temple nearby. I guess tonight�s the night, time to go."

=============================================================
* Play Information *

Game			 : Thief Gold
Level Names		 : Order of the Dew
File names		 : miss25.mis
Difficulty Settings	 : Normal/Hard/Expert
Equipment store		 : No
Map/Automap		 : No/No
New graphics		 : No
New sounds		 : No
New conversations	 : No
New models		 : No
EAX Support		 : No
Multi language support	 : No
Briefing		 : No

* Construction * 
Base                     : From scratch.
Build Time               : 12 days
		
=============================================================
* Playtesters*

- Marbleman
- Psych0sis
- skacky
- Amorphous
- therealfarfetchd
- Trickster

I think that's all, but if I forgot someone from Thief Speedtaffing server sorry.

=============================================================
* Copyright Information *

This level is � 2018 by Jayrude

Distribution of this level is allowed as long as the archive 
and this file are kept intact.

This level was not made and is not supported by 
Looking Glass Studios or Eidos Interactive.